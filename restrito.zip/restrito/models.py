from django.db import models

class SolicitacaoMatricula (models.Model):
	DtSolicitacao = models.DateField("DtSolicitacao")
	status = models.CharField("Status", max_length=50, default= "Solicitada")
	aluno = models.OneToOneField("contas.aluno", null = True, on_delete=models.CASCADE )
	
	aluno = models.ForeignKey ( 
	  "contas.Aluno",
	 null = True, on_delete=models.CASCADE),

	disciplinaOfertada = models.ForeignKey (
		"curriculo.DisciplinaOfertada", 
		null = True, on_delete=models.CASCADE)
	
	
	def __srt__(self):
		return self.nome			
	
class Atividade (models.Model):
	Descricao = models.CharField("Descricao", max_length=200)
	Conteudo = models.CharField("Conteudo", max_length=200)
	Tipo = models.CharField("Tipo", max_length=200)
	Extras = models.CharField("Extras", max_length=200)

	professor = models.ForeignKey ( 
	  "contas.Professor",
	 null = True, on_delete=models.CASCADE),	
	
	

	
	def __srt__(self):
		return self.nome
	
class AtividadeVinculada (models.Model):
	Rotulo = models.CharField("Rotulo", max_length=120)
	Status = models.CharField("Status", max_length=200)
	DtInicioRespostas = models.DateField("DtInicioRespostas")
	DtFimRespostas = models.DateField("DtFimRespostas")

	professor = models.ForeignKey( 
	  "contas.Professor",
	 null = True, on_delete=models.CASCADE),
	 
	aluno = models.ForeignKey ( 
	   "contas.Aluno",
	 null = True, on_delete=models.CASCADE),
	 
	disciplinaOfertada = models.ForeignKey ( 
	   "curriculo.DisciplinaOfertada",
	 null = True, on_delete=models.CASCADE)
	
	def __srt__(self):
		return self.nome		

class Entrega (models.Model):
	Titulo = models.CharField("Titulo", max_length=200)
	Resposta = models.CharField("Resposta", max_length=200)
	DtEntrega = models.DateField("DtEntrega")
	Status = models.CharField("Status", max_length=120, default = "Entregue")
	Nota = models.DecimalField("Nota", max_digits=4, decimal_places=2)
	Obs = models.CharField("Obs", max_length=120)
	
	professor = models.ForeignKey ( 
	  "contas.Professor",
	 null = True, on_delete=models.CASCADE),
	
	atividadeVinculada = models.OneToOneField ( 
	  AtividadeVinculada,
	 null = True, on_delete=models.CASCADE),
	 
	alunos = models.ManyToManyField( 
	  "contas.Aluno",
	 null = True), 
	
	
	
	
	def __srt__(self):
		return self.nome
