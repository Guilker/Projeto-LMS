from django.apps import AppConfig


class RestritoConfig(AppConfig):
    name = 'restrito'
