from django.shortcuts import render
from django.http import HttpResponse
sessao = 0
# Create your views here.

def restrito(request):
    if sessao == 1:
        return render(request, "restrito.html")
    else:
        return render(request, "restrito.html")


def ncurso(request):
    return render(request, "ncurso.html")

def index(request):
    return HttpResponse("olá mundo, RESTRITO")
   # return render(request, 'index.html')

def salvarcurso(request):
    nome = request.GET.get("nome")
    duracao = request.GET.get("duracao")
    modalidade = request.GET.get("modalidade")
    unidade = request.GET.get("unidade")
    mensalidade = request.GET.get("mensalidade")
    periodo = request.GET.get("periodo")
    sobrecurso = request.GET.get("sobrecurso")

    if nome !='':
        return render(request, "ndisciplina.html")
    else:
        return render(request, "ncurso.html")

def listardisc(request):
    nome = request.POST.get("nome")
    senha = request.POST.get("senha")
    return render(request, "listardisc.html")


def cadastraraluno(request):
    nome = request.POST.get("nome")
    senha = request.POST.get("senha")
    return render(request, "CadastroAluno.html")


def salvaraluno(request):
    nome = request.GET.get("nome")
    duracao = request.GET.get("duracao")
    modalidade = request.GET.get("modalidade")
    unidade = request.GET.get("unidade")
    mensalidade = request.GET.get("mensalidade")
    periodo = request.GET.get("periodo")
    sobrecurso = request.GET.get("sobrecurso")

    if nome !='':
        return render(request, "CadastroAluno.html")
    else:
        return render(request, "CadastroAluno.html")

def listaralunocurso(request):
    nome = request.POST.get("nome")
    senha = request.POST.get("senha")
    return render(request, "listaralunocurso.html")