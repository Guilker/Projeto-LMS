def autenticar(request):

    email = request.POST.get("email")
    senha = request.POST.get("senha")

    #VariavelQualquer = Tabela.objects.create(CampoDoBanco=VariavelDoForm)

    if email == 'admin' and senha == 'admin':
        sessao=1 
        return True