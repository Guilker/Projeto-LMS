from django.shortcuts import render, redirect
from django.http import HttpResponse
from contas.backend import autenticar
from django.views.decorators.csrf import csrf_exempt

sessao = 0

# Create your views here.

def index(request):
   #return HttpResponse("olá mundo, LOGIN")
   return render(request, 'login.html')

def entrar(request):
    usuario = Professor.objects.all()
    if request.method == "POST":
        if autenticar(request):
            sessao = 1
            return redirect("/restrito/ncurso/")
    else:
        retorno = "Problemas no login"
    return render(request, "login.html")


'''
def painel(request):
    if sessao == 1:
        return render(request, "painel.html")
    else:
        return render(request, "painel.html")'''