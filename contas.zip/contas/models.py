from django.db import models

class Coordenador (models.Model):
	login = models.CharField("Login", max_length=45)
	senha = models.CharField("Senha", max_length=30)
	nome = models.CharField("Nome", max_length=120)
	email = models.CharField("Email", max_length=80)
	celular= models.CharField("Celular", max_length=11)
	DtExpiração = models.DateField("DtExpiração", default= "01/01/1900",auto_now = False, auto_now_add = False)
	
	def __srt__(self):
		return self.nome
		
class Aluno (models.Model):
	login = models.CharField("Login", max_length=45)
	senha = models.CharField("Senha", max_length=30)
	nome = models.CharField("Nome", max_length=120)
	email = models.CharField("Email", max_length=80)
	celular= models.CharField("Celular", max_length=11)
	DtExpiração = models.DateField("DtExpiração", default= "01/01/1900",auto_now = False, auto_now_add = False)
	ra = models.IntegerField("RA")
	foto = models.CharField("Foto", max_length=255) 
	
	def __srt__(self):
		return self.nome
		
class Professor (models.Model):
	login = models.CharField("Login", max_length=45)
	senha = models.CharField("Senha", max_length=30)
	nome = models.CharField("Nome", max_length=120)
	email = models.CharField("Email", max_length=80)
	celular= models.CharField("Celular", max_length=11)
	DtExpiração = models.DateField("DtExpiração", default= "01/01/1900",auto_now = False, auto_now_add = False)
	ra = models.IntegerField("RA")
	
	def __srt__(self):
		return self.nome
		
		
class Mensagem (models.Model):
	Assunto = models.CharField("Assunto", max_length=100)
	Referencia = models.CharField("Referencia", max_length=120)
	Conteudo = models.CharField("Conteudo", max_length=100)
	Status = models.CharField("Status", max_length=100)
	DtEnvio = models.DateField("DtEnvio")
	DtResposta = models.DateField("DtResposta")
	Resposta = models.CharField("Resposta", max_length=200)

	professor = models.ManyToManyField ( 
	  "contas.Professor",
	 null = True),
	 
	aluno = models.ManyToManyField ( 
	  "contas.Aluno",
	 null = True)

	
	def __srt__(self):
		return self.nome
