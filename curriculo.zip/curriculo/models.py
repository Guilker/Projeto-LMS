from django.db import models

class Curso (models.Model):
	nome = models.CharField("Nome", max_length=45)
	coordenador = models.OneToOneField(
	 "contas.Coordenador", 
	 null = True, on_delete=models.CASCADE)
	 
	def __srt__(self):
		return self.nome
		
class Disciplina (models.Model):
	nome = models.CharField("Nome", max_length=45)
	data = models.DateField("Data")
	status = models.CharField("Status", max_length=50, default= "Aberta")
	PlanoEnsino = models.CharField("PlanoEnsino", max_length=120)
	CargaHorario = models.IntegerField("CargaHoraria")
	competencia = models.CharField("Competencias", max_length=200)
	habilidades = models.CharField("Habilidades", max_length=200)
	emenda = models.CharField("Emenda", max_length=200)
	ConteudoProgramatico = models.CharField("ConteudoProgramatico",max_length= 200 )
	PercentualPratico = models.DecimalField("PercentualPratico", max_digits=4, decimal_places=2)
	PercentualTeorico = models.DecimalField("PercentualTeorico", max_digits=4, decimal_places=2)
	
	def __srt__(self):
		return self.nome
		
class DisciplinaOfertada (models.Model):
	DtInicioMatricula2 = models.DateField("DtInicioMatricula2")
	DtFimMatricula2 = models.DateField("DtFimMatricula2")
	Ano = models.CharField("Ano", max_length=4)
	Semestre = models.CharField("Semestre", max_length=2)
	Turma = models.CharField("Turma", max_length=1)
	Metodologia = models.CharField("Metodologia", max_length=200)
	Recursos = models.CharField("Recursos", max_length=200)
	CriterioAvaliacao = models.CharField("CriterioAvaliacao", max_length=200)
	PlanoDeAulas = models.CharField("PlanoDeAulas", max_length=200)
	
	disciplina = models.ForeignKey ( 
	Disciplina,
	null = True, on_delete=models.CASCADE),
	
	aluno = models.ManyToManyField(
	"contas.Aluno",
	null = True)

	curso = models.ForeignKey ( 
	Curso,
	null = True, on_delete=models.CASCADE)	
	

	def __srt__(self):
		return self.nome