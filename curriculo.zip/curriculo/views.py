from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
    return HttpResponse("olá mundo, CURRICULO")
   # return render(request, 'index.html')

def login(request):
   #return HttpResponse("olá mundo, LOGIN")
   return render(request, 'index.html')

   