from django.shortcuts import render

# Create your views here.

def index(request):
   #return HttpResponse("olá mundo, LOGIN")
   return render(request, 'index.html')

def topo(request):
   #return HttpResponse("olá mundo, LOGIN")
   return render(request, 'topo.html')

def rodape(request):
   #return HttpResponse("olá mundo, LOGIN")
   return render(request, 'rodape.html')